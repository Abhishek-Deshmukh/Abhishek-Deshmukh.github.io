#!/bin/sh
# the redis server
redis-server &
# starting the task queuer
celery -A STAR_worker worker --loglevel=debug &
# the api
python3 STAR_api.py &
# serving the website
cd STAR_website/ && python3 -m http.server

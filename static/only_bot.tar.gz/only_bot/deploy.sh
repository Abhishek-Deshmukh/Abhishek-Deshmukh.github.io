#!/bin/sh
# the redis server
redis-server &
# starting the task queuer
celery -A STAR_worker worker --loglevel=debug &
# the api
python3 STAR_api.py &
# the bot
python3 STAR_bot.py

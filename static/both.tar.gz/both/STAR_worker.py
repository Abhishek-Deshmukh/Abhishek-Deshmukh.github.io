"""STAR
Abhishek Anil Deshmukh <deshmukhabhishek369@gmail.com>
the integration between celery redis and STAR
"""
from celery import Celery
import sys
sys.path.insert(0,"..")
from main import main

# how to run
# $ redis-server
# $ celery -A my_worker worker --loglevel=debug

APP = Celery(__name__, backend="rpc://", broker="redis://localhost:6379/")

@APP.task
def integrate(*args, **kwargs):
    """integration between redis and this"""
    try:
        return main(*args, **kwargs)
    except Exception as err:
        return str(err.__repr__())


ANNOTATIONS = main.__annotations__ # annotation for parameters
